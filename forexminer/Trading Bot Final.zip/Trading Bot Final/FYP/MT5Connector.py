# MT5Connector.py
import MetaTrader5 as mt5

class MT5Connector:
    def __init__(self, account, password, server):
        self.account = account
        self.password = password
        self.server = server
    
    def initialize(self):
        if not mt5.initialize():
            print("Initialization failed, error code =", mt5.last_error())
            quit()

        print("Initializing MT5 connection...")

        if not mt5.login(self.account, self.password, server=self.server):
            print("Failed to login to MetaTrader 5 account")
            mt5.shutdown()
            quit()
        print("Success")
    def fetch_account_balance():

        # Initialize MT5 connection
        if not mt5.initialize():
            print("initialize() failed, error code =", mt5.last_error())
            return None
    
        # Fetch account info
        account_info = mt5.account_info()
        if account_info is None:
            print("Failed to get account info, error code =", mt5.last_error())
            return None
        
        # Return the account balance
        return account_info.balance