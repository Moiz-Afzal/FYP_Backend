from MT5Connector import MT5Connector
from CandlestickPatterns import CandlestickPatterns
import MetaTrader5 as mt5
import pandas as pd
import time

capital = MT5Connector.fetch_account_balance()

def place_order(symbol, order_type, lot_size, stop_loss_points, take_profit_points):
    """Place an order with dynamic stop loss and take profit."""
    symbol_info = mt5.symbol_info(symbol)
    if symbol_info is None:
        print(f"{symbol} not found, cannot place order.")
        return
    
    if not symbol_info.visible:
        if not mt5.symbol_select(symbol, True):
            print(f"Failed to select {symbol}.")
            return
    
    price = mt5.symbol_info_tick(symbol).ask if order_type == "BUY" else mt5.symbol_info_tick(symbol).bid
    point = symbol_info.point
    
    sl = price - stop_loss_points * point if order_type == "BUY" else price + stop_loss_points * point
    tp = price + take_profit_points * point if order_type == "BUY" else price - take_profit_points * point

    request = {
        "action": mt5.TRADE_ACTION_DEAL,
        "symbol": symbol,
        "volume": lot_size,
        "type": mt5.ORDER_TYPE_BUY if order_type == "BUY" else mt5.ORDER_TYPE_SELL,
        "price": price,
        "sl": sl,
        "tp": tp,
        "magic": 1000,
        "comment": "Automated script trade",
        "type_time": mt5.ORDER_TIME_GTC,
        "type_filling": mt5.ORDER_FILLING_IOC,
    }
    
    result = mt5.order_send(request)
    if result.retcode != mt5.TRADE_RETCODE_DONE:
        print(f"Order failed, retcode={result.retcode}")
    else:
        print(f"Order placed successfully, {order_type}, {lot_size} lots of {symbol}")


        

def analyze_timeframe(df, timeframe_name):
    """Analyze the dataframe for bullish, bearish, or neutral patterns and return the results."""
    results = {
        "bullish": [],
        "bearish": [],
        "neutral": []
    }

    # Single candle patterns
    if CandlestickPatterns.is_doji(df.iloc[-1]):
        results["neutral"].append("Doji")
    if CandlestickPatterns.is_hammer(df.iloc[-1]):
        results["bullish"].append("Hammer")
    if CandlestickPatterns.is_inverted_hammer(df.iloc[-1]):
        results["bullish"].append("Inverted Hammer")
    if CandlestickPatterns.is_hanging_man(df.iloc[-1]):
        results["bearish"].append("Hanging Man")
    if CandlestickPatterns.is_shooting_star(df.iloc[-1]):
        results["bearish"].append("Shooting Star")

    # Patterns requiring the last 2 candles
    if len(df) >= 2:
        if CandlestickPatterns.is_bullish_engulfing(df.iloc[-1], df.iloc[-2]):
            results["bullish"].append("Bullish Engulfing")
        if CandlestickPatterns.is_bearish_engulfing(df.iloc[-1], df.iloc[-2]):
            results["bearish"].append("Bearish Engulfing")
        if CandlestickPatterns.is_bullish_harami(df.iloc[-1], df.iloc[-2]):
            results["bullish"].append("Bullish Harami")
        if CandlestickPatterns.is_bearish_harami(df.iloc[-1], df.iloc[-2]):
            results["bearish"].append("Bearish Harami")


        for i in range(2, len(df)):  # Start from 2 since we need at least 3 candles
            chunk = df.iloc[i-2:i+1]
            # Use a fixed local index for three-candle patterns
            local_index = 2  # This corresponds to the third candle in the chunk
    
            # Example for methods requiring the last 3 candles and an index
            if CandlestickPatterns.is_morning_star(chunk, local_index):
                results["bullish"].append("Morning Star")
            if CandlestickPatterns.is_evening_star(chunk, local_index):
                results["bearish"].append("Evening Star")
            if CandlestickPatterns.is_three_white_soldiers(chunk, local_index):
                results["bullish"].append("Three White Soldiers")
            if CandlestickPatterns.is_three_black_crows(chunk, local_index):
                results["bearish"].append("Three Black Crows")
    return results

 

def fetch_and_analyze(symbol, timeframe):
    """Fetch the latest candle data for the specified timeframe and symbol and analyze it."""
    rates = mt5.copy_rates_from_pos(symbol, timeframe, 0, 20)  # Fetch more candles to accommodate patterns requiring more data
    # Check if rates is not None and has elements
    if rates is not None and len(rates) > 0:
        df = pd.DataFrame(rates)
        # Convert 'time' to a readable format
        df['time'] = pd.to_datetime(df['time'], unit='s')
        return analyze_timeframe(df, timeframe)  # Adjusted to directly analyze the dataframe
    else:
        print(f"Failed to fetch rates for {symbol} in {timeframe} timeframe.")
        return {
            "bullish": [],
            "bearish": [],
            "neutral": []
        }

def analyze_and_trade(symbol, capital , timeframe):
    # Placeholder for getting current analysis results. Needs actual implementation.
    analysis_results = fetch_and_analyze(symbol , timeframe)  # This should return a dictionary with the analysis.
    
    # Example values for TP and SL based on chart patterns. Should be replaced with actual logic.
    suggested_tp, suggested_sl = 50, 25  # These are placeholders.

    bullish_count = sum(1 for result in analysis_results.values() if 'bullish' in result)
    bearish_count = sum(1 for result in analysis_results.values() if 'bearish' in result)

    # Adjust risk percentage based on the count of bullish patterns.
    risk_percentage = 3 if bullish_count >= 3 else 2
    risk_manager = RiskManager(capital, risk_percentage)

    # Determine market entry price for simplicity.
    entry_price = mt5.symbol_info_tick(symbol).ask  # Assuming a buy order.
    # Adjusting TP and SL based on suggested values and entry price.
    tp_price = entry_price + suggested_tp * mt5.symbol_info(symbol).point
    sl_price = entry_price - suggested_sl * mt5.symbol_info(symbol).point

    if bullish_count > bearish_count:
        print(f"Placing BUY order for {symbol} based on bullish sentiment.")
        lot_size = risk_manager.calculate_lot_size(entry_price, sl_price, symbol)
        place_order(symbol, "BUY", lot_size, suggested_sl, suggested_tp)
    elif bearish_count > bullish_count:
        print(f"Placing SELL order for {symbol} based on bearish sentiment.")
        lot_size = risk_manager.calculate_lot_size(entry_price, sl_price, symbol)
        # For a SELL order, ensure tp_price and sl_price are adjusted accordingly.
        place_order(symbol, "SELL", lot_size, suggested_sl, suggested_tp)
    else:
        print("Sentiment is neutral. No action taken.")
        
def analyze_all_timeframes(connector, symbol, timeframes):
    results = {}
    for timeframe_name, timeframe in timeframes.items():
        print(f"Analyzing {timeframe_name} timeframe for {symbol}...")
        patterns = fetch_and_analyze(symbol, timeframe)  # Pass symbol here
        results[timeframe_name] = patterns
    return results


if __name__ == "__main__":
    account = 69620949
    password = "123@Trader"
    server = "XMGlobal-MT5 2"
    symbol = "GOLD"
    
    connector = MT5Connector(account, password, server)
    connector.initialize()

    timeframes = {
        "15M": mt5.TIMEFRAME_M15,
        "30M": mt5.TIMEFRAME_M30,
        "1H": mt5.TIMEFRAME_H1,
        "4H": mt5.TIMEFRAME_H4,
        "D1": mt5.TIMEFRAME_D1
    }


    
    while True:
        analysis_results = analyze_all_timeframes(connector, symbol, timeframes)
        for timeframe, result in analysis_results.items():
            bullish_patterns = ', '.join(set(result["bullish"]))  # Convert list to set to remove duplicates
            bearish_patterns = ', '.join(set(result["bearish"]))  # Convert list to set to remove duplicates
            if bullish_patterns or bearish_patterns:
                sentiment = "bullish" if len(result["bullish"]) > len(result["bearish"]) else "bearish"
                print(f"In the {timeframe} timeframe, sentiment is {sentiment} due to bullish patterns: {bullish_patterns} and bearish patterns: {bearish_patterns}")
            else:
                print(f"In the {timeframe} timeframe, no significant patterns found.")

        analyze_and_trade(symbol , capital , timeframe)
        print("Sleeping for next analysis cycle...")
        time.sleep(60)