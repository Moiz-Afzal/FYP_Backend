import MetaTrader5 as mt5
import pandas as pd
import time
print("Ini")
# Initialize and login to MT5
if not mt5.initialize():
    print("Initialization failed, error code =", mt5.last_error())
    qu7it()

print("Initializing MT5 connection...")

account = 69620949
password = "123@Trader"
server = "XMGlobal-MT5 2"
if not mt5.login(account, password, server=server):
    print("Failed to login to MetaTrader 5 account")
    mt5.shutdown()
    quit()
print("Success")

symbol = "GOLD"
timeframes = {
    "15M": mt5.TIMEFRAME_M15,  # Added 15-minute timeframe
    "30M": mt5.TIMEFRAME_M30,
    "1H": mt5.TIMEFRAME_H1,
    "4H": mt5.TIMEFRAME_H4,
    "D1": mt5.TIMEFRAME_D1
}
def is_doji(row, threshold=0.001):
    return abs(row['open'] - row['close']) <= threshold

def is_hammer(row, body_threshold=0.002, shadow_ratio=2):
    body = abs(row['open'] - row['close'])
    lower_shadow = min(row['open'], row['close']) - row['low']
    upper_shadow = row['high'] - max(row['open'], row['close'])
    return body <= body_threshold and lower_shadow >= (body * shadow_ratio) and upper_shadow <= body

def is_hanging_man(row, body_threshold=0.002, shadow_ratio=2):
    body = abs(row['open'] - row['close'])
    lower_shadow = min(row['open'], row['close']) - row['low']
    upper_shadow = row['high'] - max(row['open'], row['close'])
    return body <= body_threshold and lower_shadow >= (body * shadow_ratio) and upper_shadow <= body

def is_inverted_hammer(row, body_threshold=0.002, shadow_ratio=2):
    body = abs(row['open'] - row['close'])
    lower_shadow = min(row['open'], row['close']) - row['low']
    upper_shadow = row['high'] - max(row['open'], row['close'])
    return body <= body_threshold and upper_shadow >= (body * shadow_ratio) and lower_shadow <= body

def is_shooting_star(row, body_threshold=0.002, shadow_ratio=2):
    body = abs(row['open'] - row['close'])
    lower_shadow = min(row['open'], row['close']) - row['low']
    upper_shadow = row['high'] - max(row['open'], row['close'])
    return body <= body_threshold and upper_shadow >= (body * shadow_ratio) and lower_shadow <= body

def is_bullish_engulfing(current_row, previous_row):
    return current_row['close'] > current_row['open'] and \
           previous_row['close'] < previous_row['open'] and \
           current_row['open'] <= previous_row['close'] and \
           current_row['close'] >= previous_row['open']

def is_bearish_engulfing(current_row, previous_row):
    return current_row['close'] < current_row['open'] and \
           previous_row['close'] > previous_row['open'] and \
           current_row['open'] >= previous_row['close'] and \
           current_row['close'] <= previous_row['open']

def is_tweezer_tops(chunk, index, tolerance=0.001):
    if index == 0:
        return False
    current_high = chunk.iloc[index]['high']
    previous_high = chunk.iloc[index - 1]['high']
    return abs(current_high - previous_high) <= tolerance

def is_tweezer_bottoms(chunk, index, tolerance=0.001):
    if index == 0:
        return False
    current_low = chunk.iloc[index]['low']
    previous_low = chunk.iloc[index - 1]['low']
    return abs(current_low - previous_low) <= tolerance

def is_bullish_harami(current_row, previous_row):
    return previous_row['close'] < previous_row['open'] and \
           current_row['close'] > current_row['open'] and \
           previous_row['open'] > current_row['close'] and \
           previous_row['close'] < current_row['open']

def is_bearish_harami(current_row, previous_row):
    return previous_row['close'] > previous_row['open'] and \
           current_row['close'] < current_row['open'] and \
           previous_row['close'] > current_row['open'] and \
           previous_row['open'] < current_row['close']


def is_morning_star(chunk, index):
    if index < 2:
        return False
    first_candle = chunk.iloc[index - 2]
    second_candle = chunk.iloc[index - 1]
    third_candle = chunk.iloc[index]

    return first_candle['close'] > first_candle['open'] and \
           second_candle['close'] < second_candle['open'] and \
           third_candle['close'] > third_candle['open'] and \
           second_candle['close'] < first_candle['low'] and \
           third_candle['close'] > second_candle['open']

def is_evening_star(chunk, index):
    if index < 2:
        return False
    first_candle = chunk.iloc[index - 2]
    second_candle = chunk.iloc[index - 1]
    third_candle = chunk.iloc[index]

    return first_candle['close'] < first_candle['open'] and \
           second_candle['close'] > second_candle['open'] and \
           third_candle['close'] < third_candle['open'] and \
           second_candle['close'] > first_candle['high'] and \
           third_candle['close'] < second_candle['open']

def is_three_white_soldiers(chunk, index):
    if index < 2:
        return False
    first_candle = chunk.iloc[index - 2]
    second_candle = chunk.iloc[index - 1]
    third_candle = chunk.iloc[index]

    return all([
        first_candle['close'] > first_candle['open'],
        second_candle['close'] > second_candle['open'],
        third_candle['close'] > third_candle['open'],
        first_candle['close'] < second_candle['open'],
        second_candle['close'] < third_candle['open'],
        third_candle['close'] > first_candle['high'],
        second_candle['close'] > first_candle['close'],
        third_candle['close'] > second_candle['close']
    ])

def is_three_black_crows(chunk, index):
    if index < 2:
        return False
    first_candle = chunk.iloc[index - 2]
    second_candle = chunk.iloc[index - 1]
    third_candle = chunk.iloc[index]

    return all([
        first_candle['close'] < first_candle['open'],
        second_candle['close'] < second_candle['open'],
        third_candle['close'] < third_candle['open'],
        first_candle['close'] > second_candle['open'],
        second_candle['close'] > third_candle['open'],
        third_candle['close'] < first_candle['low'],
        second_candle['close'] < first_candle['close'],
        third_candle['close'] < second_candle['close']
    ])

def is_three_inside_up(chunk, index):
    if index < 2:
        return False
    first_candle = chunk.iloc[index - 2]
    second_candle = chunk.iloc[index - 1]
    third_candle = chunk.iloc[index]

    return first_candle['close'] < first_candle['open'] and \
           second_candle['close'] > second_candle['open'] and \
           second_candle['open'] < first_candle['close'] and \
           second_candle['close'] < first_candle['open'] and \
           third_candle['close'] > first_candle['high']

def is_three_inside_down(chunk, index):
    if index < 2:
        return False
    first_candle = chunk.iloc[index - 2]
    second_candle = chunk.iloc[index - 1]
    third_candle = chunk.iloc[index]

    return first_candle['close'] > first_candle['open'] and \
           second_candle['close'] < second_candle['open'] and \
           second_candle['open'] > first_candle['close'] and \
           second_candle['close'] > first_candle['open'] and \
           third_candle['close'] < first_candle['low']

def analyze_timeframe(df, timeframe_name):
    """Analyze the dataframe for bullish, bearish, or neutral patterns and return the sentiment."""
    bullish_patterns = 0
    bearish_patterns = 0
    neutral_patterns = 0

    # Check for Doji (neutral pattern) in the last candle
    if is_doji(df.iloc[-1]):
        neutral_patterns += 1

    # Check for Hammer (bullish pattern) in the last candle
    if is_hammer(df.iloc[-1]):
        bullish_patterns += 1

    # Check for Bullish Engulfing in the last two candles
    if len(df) >= 2 and is_bullish_engulfing(df.iloc[-1], df.iloc[-2]):
        bullish_patterns += 1

    # Check for Bearish Engulfing in the last two candles
    if len(df) >= 2 and is_bearish_engulfing(df.iloc[-1], df.iloc[-2]):
        bearish_patterns += 1

    # Determine sentiment based on the pattern counts
    if bullish_patterns > bearish_patterns:
        return "bullish"
    elif bearish_patterns > bullish_patterns:
        return "bearish"
    elif neutral_patterns > 0:
        return "neutral"
    else:
        return "undetermined"


try:
    while True:
        for name, timeframe in timeframes.items():
            rates = mt5.copy_rates_from_pos(symbol, timeframe, 0, 50)  # Last 50 bars
            if rates is not None and len(rates) > 0:
                df = pd.DataFrame(rates)
                df['time'] = pd.to_datetime(df['time'], unit='s')
                sentiment = analyze_timeframe(df, name)
                print(f"{name} timeframe is {sentiment}.")
            else:
                print(f"Failed to fetch rates for {name} timeframe.")
        
        # Wait for a specified time before the next check (e.g., 300 seconds = 5 minutes)
        print("Waiting for the next analysis cycle...")
        time.sleep(300)

except KeyboardInterrupt:
    print("Script terminated by user.")

# Shutdown MT5 connection
mt5.shutdown()