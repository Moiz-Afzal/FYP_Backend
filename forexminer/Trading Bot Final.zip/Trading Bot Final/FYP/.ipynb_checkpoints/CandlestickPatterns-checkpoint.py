class CandlestickPatterns:
    @staticmethod
    def is_doji(row, threshold=0.001):
        return abs(row['open'] - row['close']) <= threshold
    
    @staticmethod
    def is_hammer(row, body_threshold=0.002, shadow_ratio=2):
        body = abs(row['open'] - row['close'])
        lower_shadow = min(row['open'], row['close']) - row['low']
        upper_shadow = row['high'] - max(row['open'], row['close'])
        return body <= body_threshold and lower_shadow >= (body * shadow_ratio) and upper_shadow <= body
    
    @staticmethod
    def is_hanging_man(row, body_threshold=0.002, shadow_ratio=2):
        body = abs(row['open'] - row['close'])
        lower_shadow = min(row['open'], row['close']) - row['low']
        upper_shadow = row['high'] - max(row['open'], row['close'])
        return body <= body_threshold and lower_shadow >= (body * shadow_ratio) and upper_shadow <= body
    
    @staticmethod
    def is_inverted_hammer(row, body_threshold=0.002, shadow_ratio=2):
        body = abs(row['open'] - row['close'])
        lower_shadow = min(row['open'], row['close']) - row['low']
        upper_shadow = row['high'] - max(row['open'], row['close'])
        return body <= body_threshold and upper_shadow >= (body * shadow_ratio) and lower_shadow <= body
    
    @staticmethod
    def is_shooting_star(row, body_threshold=0.002, shadow_ratio=2):
        body = abs(row['open'] - row['close'])
        lower_shadow = min(row['open'], row['close']) - row['low']
        upper_shadow = row['high'] - max(row['open'], row['close'])
        return body <= body_threshold and upper_shadow >= (body * shadow_ratio) and lower_shadow <= body

    @staticmethod
    def is_spinning_top(candle):
        # Example logic based on the size of the candle's body vs wicks
        body_size = abs(candle['close'] - candle['open'])
        wick_size_top = candle['high'] - max(candle['close'], candle['open'])
        wick_size_bottom = min(candle['close'], candle['open']) - candle['low']
        
        # Conditions for a spinning top can vary, but it's typically a small body with larger wicks
        if body_size < wick_size_top and body_size < wick_size_bottom:
            return True
        return False
        
    @staticmethod
    def is_bullish_engulfing(current_row, previous_row):
        return current_row['close'] > current_row['open'] and \
               previous_row['close'] < previous_row['open'] and \
               current_row['open'] <= previous_row['close'] and \
               current_row['close'] >= previous_row['open']
    
    @staticmethod
    def is_bearish_engulfing(current_row, previous_row):
        return current_row['close'] < current_row['open'] and \
               previous_row['close'] > previous_row['open'] and \
               current_row['open'] >= previous_row['close'] and \
               current_row['close'] <= previous_row['open']
    
    @staticmethod
    def is_tweezer_tops(chunk, index, tolerance=0.001):
        print(f"Index: {index}, Current High: {current_high}, Previous High: {previous_high}")
        if index == 0:
            return False
        current_high = chunk.iloc[index]['high']
        previous_high = chunk.iloc[index - 1]['high']
        return abs(current_high - previous_high) <= tolerance
    
    @staticmethod
    def is_tweezer_bottoms(chunk, index, tolerance=0.001):
        if index == 0:
            return False
        current_low = chunk.iloc[index]['low']
        previous_low = chunk.iloc[index - 1]['low']
        return abs(current_low - previous_low) <= tolerance
    
    @staticmethod
    def is_bullish_harami(current_row, previous_row):
        return previous_row['close'] < previous_row['open'] and \
               current_row['close'] > current_row['open'] and \
               previous_row['open'] > current_row['close'] and \
               previous_row['close'] < current_row['open']
    
    @staticmethod
    def is_bearish_harami(current_row, previous_row):
        return previous_row['close'] > previous_row['open'] and \
               current_row['close'] < current_row['open'] and \
               previous_row['close'] > current_row['open'] and \
               previous_row['open'] < current_row['close']
    
    @staticmethod
    def is_morning_star(chunk, index):
        if index < 2:
            return False
        first_candle = chunk.iloc[index - 2]
        second_candle = chunk.iloc[index - 1]
        third_candle = chunk.iloc[index]
        return first_candle['close'] > first_candle['open'] and \
               second_candle['close'] < second_candle['open'] and \
               third_candle['close'] > third_candle['open'] and \
               second_candle['close'] < first_candle['low'] and \
               third_candle['close'] > second_candle['open']
    
    @staticmethod
    def is_evening_star(chunk, index):
        if index < 2:
            return False
        first_candle = chunk.iloc[index - 2]
        second_candle = chunk.iloc[index - 1]
        third_candle = chunk.iloc[index]
        return first_candle['close'] < first_candle['open'] and \
               second_candle['close'] > second_candle['open'] and \
               third_candle['close'] < third_candle['open'] and \
               second_candle['close'] > first_candle['high'] and \
               third_candle['close'] < second_candle['open']
    
    @staticmethod
    def is_three_white_soldiers(chunk, index):
        if index < 2:
            return False
        first_candle = chunk.iloc[index - 2]
        second_candle = chunk.iloc[index - 1]
        third_candle = chunk.iloc[index]
        return all([
            first_candle['close'] > first_candle['open'],
            second_candle['close'] > second_candle['open'],
            third_candle['close'] > third_candle['open'],
            first_candle['close'] < second_candle['open'],
            second_candle['close'] < third_candle['open'],
            third_candle['close'] > first_candle['high'],
            second_candle['close'] > first_candle['close'],
            third_candle['close'] > second_candle['close']
        ])
    
    @staticmethod
    def is_three_black_crows(chunk, index):
        if index < 2:
            return False
        first_candle = chunk.iloc[index - 2]
        second_candle = chunk.iloc[index - 1]
        third_candle = chunk.iloc[index]
        return all([
            first_candle['close'] < first_candle['open'],
            second_candle['close'] < second_candle['open'],
            third_candle['close'] < third_candle['open'],
            first_candle['close'] > second_candle['open'],
            second_candle['close'] > third_candle['open'],
            third_candle['close'] < first_candle['low'],
            second_candle['close'] < first_candle['close'],
            third_candle['close'] < second_candle['close']
        ])
    
    @staticmethod
    def is_three_inside_up(chunk, index):
        if index < 2:
            return False
        first_candle = chunk.iloc[index - 2]
        second_candle = chunk.iloc[index - 1]
        third_candle = chunk.iloc[index]
        return first_candle['close'] < first_candle['open'] and \
               second_candle['close'] > second_candle['open'] and \
               second_candle['open'] < first_candle['close'] and \
               second_candle['close'] < first_candle['open'] and \
               third_candle['close'] > first_candle['high']
    
    @staticmethod
    def is_three_inside_down(chunk, index):
        if index < 2:
            return False
        first_candle = chunk.iloc[index - 2]
        second_candle = chunk.iloc[index - 1]
        third_candle = chunk.iloc[index]
        return first_candle['close'] > first_candle['open'] and \
               second_candle['close'] < second_candle['open'] and \
               second_candle['open'] > first_candle['close'] and \
               second_candle['close'] > first_candle['open'] and \
               third_candle['close'] < first_candle['low']

