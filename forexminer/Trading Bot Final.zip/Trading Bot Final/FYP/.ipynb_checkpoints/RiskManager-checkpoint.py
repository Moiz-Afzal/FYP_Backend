class RiskManager:
    def __init__(self, capital, entry_price, tp_price, sl_price, risk_per_trade_percentage=1):
        self.capital = capital
        self.entry_price = abs(entry_price)
        self.tp_price = abs(tp_price)
        self.sl_price = abs(sl_price)
        self.risk_per_trade = abs(risk_per_trade_percentage / 100) * capital
    @staticmethod
    def truncate_to_two_digits(number):
        return int(number * 100) / 100.0
        
    def calculate_lot_size(self, asset='EURUSD'):
        # Ensure the price difference is calculated as an absolute value in pips
        price_difference_pips = abs(abs(self.tp_price - self.sl_price) * 10000 if 'JPY' not in asset.upper() else abs(self.tp_price - self.sl_price) * 100)
        # Assuming a standard risk value per pip for simplicity; this is for a standard lot (100,000 units)
        value_per_pip = 10
        # Calculate the maximum loss allowed per trade as an absolute value to ensure positive lot size
        max_loss = abs(self.risk_per_trade)
        
        # Calculate and return the lot size
        lot_size = max_loss / (price_difference_pips * value_per_pip)

        adjusted_lot_size = RiskManager.truncate_to_two_digits(lot_size)
        return adjusted_lot_size

